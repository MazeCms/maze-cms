<div class="demo winget-id-<?php echo $id_wid ?> position-<?php echo $position ?>">
<div class="demo-heads"><?php echo $title ?></div>
<div class="demo-body"><?php echo $body ?></div>
<div class="demo-foter"></div>
</div>