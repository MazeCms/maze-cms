<div class="mywrap winget-id-<?php echo $id_wid ?> position-<?php echo $position ?>">
<div class="mywrap-heads"><?php echo $title ?></div>
<div class="mywrap-body"><?php echo $body ?></div>
<div class="mywrap-foter"></div>
</div>