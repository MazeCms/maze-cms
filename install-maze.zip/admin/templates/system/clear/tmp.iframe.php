<!DOCTYPE HTML>
<html>
<head>
    {HEADER}
</head>
<body><?php if ($this->isMessage()): ?>{MESSAGE}<?php endif; ?>
    {CONTENT}
</body>
</html>
