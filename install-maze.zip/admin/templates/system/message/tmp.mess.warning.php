<div class="alert alert-block">
	<button type="button" class="close" onclick="cms.closeMess(this)" data-dismiss="alert">&times;</button>
	<strong><?php echo Text::_("LIB_FRAMEWORK_DOCUMENT_MESS_WARNING"); ?></strong></br>
	 <?php echo Text::_($text); ?>
</div>