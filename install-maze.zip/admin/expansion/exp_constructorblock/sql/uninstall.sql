DROP TABLE IF EXISTS {{%constructorblock_view}};
DROP TABLE IF EXISTS {{%constructorblock_sort}};
DROP TABLE IF EXISTS {{%constructorblock_filter}};
DROP TABLE IF EXISTS {{%constructorblock_block}};




