<?php

defined('_CHECK_') or die("Access denied");

class Widget_View_Widget extends View {

    public function registry() {
        
    }

}

?>