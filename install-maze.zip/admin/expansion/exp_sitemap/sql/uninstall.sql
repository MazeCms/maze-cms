DROP TABLE IF EXISTS {{%sitemap_visits}};
DROP TABLE IF EXISTS {{%sitemap_link}};
DROP TABLE IF EXISTS {{%sitemap_robots}};
DROP TABLE IF EXISTS {{%sitemap}};








