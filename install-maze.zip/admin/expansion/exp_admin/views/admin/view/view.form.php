<?php

use maze\helpers\ArrayHelper;

defined('_CHECK_') or die("Access denied");

class Admin_View_Admin extends View {

    public function registry() {
        
    }

}

?>