<?php

defined('_CHECK_') or die("Access denied");

//$doc = Document::instance();
//$doc->addScript("/admin/expansion/exp_menu/js/jstreesite.js");
//
//$doc->setLangTextScritp(array(
//    "EXP_MENU_PANELSITE_STRUCTUR",
//    "EXP_MENU_PANELSITE_EXPAND",
//    "EXP_MENU_PANELSITE_COLLAPSE"
//));
//
//RC::app()->getToolbar()->addGroup("system", new Buttonset(array(
//    "TITLE" => "EXP_MENU_PANELSITE_STRUCTUR",
//    "TYPE" => "BIG",
//    "SORT" => 1,
//    "SORTGROUP" => 10,
//    "SRC" => "/admin/expansion/exp_menu/images/icon-foldertree.png",
//    "HINT" => array("TITLE" => "EXP_MENU_PANELSITE_STRUCTUR", "TEXT" => "EXP_MENU_PANELSITE_STRUCTUR_DES"),
//    "ACTION" => "menu_tree_structure() ;return false;"
//        ))
//);
?>