<?php

defined('_CHECK_') or die("Access denied");

class Menu_View_Groupmenu extends View {

    
}

?>