<?php

defined('_CHECK_') or die("Access denied");

class User_View_User extends View {

    public function registry() {
        
    }

}

?>