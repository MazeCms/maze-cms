<h1>Здаствуйте многоуважаемый(ая) <?=$user->name;?></h1>
<br><br>
<div><?=$messages?></div>
