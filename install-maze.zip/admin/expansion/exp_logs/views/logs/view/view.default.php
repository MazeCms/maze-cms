<?php

defined('_CHECK_') or die("Access denied");

class Logs_View_Logs extends View {

    public function registry() {

      
       
        
    }

}

?>